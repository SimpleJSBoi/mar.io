  var map = arguments[0] || new Map();

  map.time = 9999;
  map.locs = [ new Location(0, true) ];
  map.areas = [
    new Area('Underwater', function() {
      setLocationGeneration(0);

      
      pushPreThing(Floor, 16, 0, 8);
      pushPreThing(Cannon, 160, 48, 1);
      pushPreThing(Cannon, 160, 40, 1);
      pushPreThing(Cannon, 160, 32, 1);
      pushPreThing(Floor, 164, 0, 8);
      pushPreThing(Cannon, 168, 56, 1);
      pushPreThing(Cannon, 168, 24, 1);
      pushPreThing(Cannon, 176, 56, 1);
      pushPreThing(Cannon, 176, 40, 1);
      pushPreThing(Cannon, 176, 24, 1);
      pushPreThing(Cannon, 184, 40, 1);
      pushPreThing(Cannon, 184, 32, 1);
      pushPreThing(Cannon, 200, 48, 1);
      pushPreThing(Cannon, 200, 40, 1);
      pushPreThing(Cannon, 200, 32, 1);
      pushPreThing(Cannon, 208, 56, 1);
      pushPreThing(Cannon, 208, 24, 1);
      pushPreThing(Cannon, 216, 56, 1);
      pushPreThing(Cannon, 216, 40, 1);
      pushPreThing(Cannon, 216, 24, 1);
      pushPreThing(Cannon, 224, 40, 1);
      pushPreThing(Cannon, 224, 32, 1);
    })
  ];
  return map;